        
    </div>
    <footer class="hdev__footer">
            <div class="hdev__footer-container">
                <div class="hdev__footer-content">
                        <p>Copyright©2022 All rights reserved | hecho con <span><img src="img/heart.svg" alt=""></span> por Harly</p>
                </div>
            </div>
    </footer>
<script>
    var eliminar = document.querySelector("div[style='text-align: right;position: fixed;z-index:9999999;bottom: 0;width: auto;right: 1%;cursor: pointer;line-height: 0;display:block !important;']");
    eliminar.classList.add("anotherclass");
</script>
</body>
</html>